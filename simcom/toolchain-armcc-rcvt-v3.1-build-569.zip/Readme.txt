There are two folders 
1) The "Flexlm" having license.dat file.
2) The "RVCT_EAT" having compiler files.

//================================================
first, open "license.dat" file in "Flexlm" and replace "HOSTID" value with MAC address of network adaptor.
go to CMD -> ipconfig /all.
get Physical address of Ethernet/WiFi adaptor. it is somethiNg like 00-1E-64-FD-3B-85
in license.dat file you may find "HOSTID=5C879C5691B9" in many places. replace them with new address like "HOSTID=001E64FD3B85"
 
//================================================
to setup the compiler environment follow either methods.
A) copy "Flexlm" to "C" drive. that is root folder.

B) Method-1
---1) "RVCT_EAT" in "C" drive.
---3) go to your SDK folder. something like "1418B02SIM868M32" or "SDK_1418B01SIM868M32_EAT" folder.
	go to "build" folder in it. and open "user.mak" file. find "DIR_ARM" in that file and give path of "RCVT_EAT" folder in "C" drive. for example: "DIR_ARM  =  C:\RVCT_EAT"

B) Method-2
---1) create folders "ARM and RVCT" in "C:\Program Files" such that path becomes, "C:\Program Files\ARM\RCVT".
---2) copy material in "RVCT_EAT" in newly created "RCVT" folder.
---3) give this path to "DIR_ARM"